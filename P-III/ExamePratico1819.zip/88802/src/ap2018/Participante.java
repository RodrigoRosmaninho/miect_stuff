package ap2018;

public class Participante {
    private String email;
    private String nome;

    public Participante(String email, String nome) {
        this.email = email;
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return "Participante [" +
                "email=" + email +
                ", nome=" + nome +
                ']';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Participante)) return false;

        Participante that = (Participante) o;

        if (getEmail() != null ? !getEmail().equals(that.getEmail()) : that.getEmail() != null) return false;
        return getNome() != null ? getNome().equals(that.getNome()) : that.getNome() == null;
    }

    @Override
    public int hashCode() {
        int result = getEmail() != null ? getEmail().hashCode() : 0;
        result = 31 * result + (getNome() != null ? getNome().hashCode() : 0);
        return result;
    }
}
