package ap2018;

import java.util.*;
import java.util.stream.Collectors;

public class Feira {
    private String nome;
    private String local;
    private Set<Expositor> stands;
    private List<Visitante> visitantes;

    public Feira(String nome, String local) {
        this.nome = nome;
        this.local = local;
        stands = new HashSet<>();
        visitantes = new ArrayList<>();
    }

    public void add(Stand s){
        stands.add(s);
    }

    public void add(Visitante v){
        visitantes.add(v);
    }

    public String emailsDosResponsaveis(){
        return "[" + stands.stream().map(Expositor::responsavel).map(Participante::getEmail).collect(Collectors.joining(", ")) + "]";
    }

    public String visitantesEntreDatas(String begin, String end){
        return "[" + visitantes.stream().filter(v -> v.getData().compareTo(begin) >= 0).filter(v -> v.getData().compareTo(end) <= 0).map(Visitante::toString).collect(Collectors.joining(", ")) + "]";
    }

    public String getServico(Servico serv){
        return "[" + stands.stream().filter(s -> s instanceof StandServicos).map(s -> (StandServicos) s).filter(s -> s.getServico().equals(serv)).map(StandServicos::toString).collect(Collectors.joining(", ")) + "]";
    }

    public Set<Expositor> getStandsOrderedByCodigo(){
        Set<Expositor> temp = new TreeSet<>(Comparator.comparing(Expositor::codigo));
        temp.addAll(stands);
        return temp;
    }

    public String getNome() {
        return nome;
    }

    public String getLocal() {
        return local;
    }

    @Override
    public String toString() {
        return "Feira " + nome + " - Total de Expositores: " + stands.size() + "; Total de Visitantes: " + visitantes.size();
    }
}
