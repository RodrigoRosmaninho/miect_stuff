package ap2018;

public class StandServicos extends Stand{
    private Servico servico;

    public StandServicos(String codigo, String nome, Participante responsavel, Servico servico) {
        super(codigo, nome, responsavel);
        this.servico = servico;
    }

    public Servico getServico() {
        return servico;
    }

    @Override
    public String toString() {
        return "StandServicos [" +
                "servico=" + servico +
                "] " + super.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StandServicos)) return false;
        if (!super.equals(o)) return false;

        StandServicos that = (StandServicos) o;

        return getServico() == that.getServico();
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (getServico() != null ? getServico().hashCode() : 0);
        return result;
    }
}
