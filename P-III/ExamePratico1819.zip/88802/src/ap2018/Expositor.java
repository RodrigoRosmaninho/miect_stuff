package ap2018;

public interface Expositor {
    String codigo();
    Participante responsavel();
}
