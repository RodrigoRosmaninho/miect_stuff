package ap2018;

import java.util.ArrayList;
import java.util.List;

public class StandEmpresa extends Stand {
    private List<Participante> membros;

    public StandEmpresa(String codigo, String nome, Participante responsavel) {
        super(codigo, nome, responsavel);
        membros = new ArrayList<>();
        membros.add(responsavel);
    }

    public StandEmpresa(String codigo, String nome, Participante responsavel, List<Participante> lista) {
        super(codigo, nome, responsavel);
        membros = lista;
    }

    public void add(Participante p){
        membros.add(p);
    }

    public List<Participante> membros() {
        return membros;
    }

    @Override
    public String toString() {
        return "StandEmpresa [" +
                "lista=" + membros +
                "] " + super.toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StandEmpresa)) return false;
        if (!super.equals(o)) return false;

        StandEmpresa that = (StandEmpresa) o;

        return membros != null ? membros.equals(that.membros) : that.membros == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (membros != null ? membros.hashCode() : 0);
        return result;
    }
}
